import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { sendMessagingConversion } from "@/lib/meta-capi";
import {
  ESTIMATE_STATUSES,
  STATUSES,
  TOUCH_OPTIONS,
  normalizeLeadStatus,
  normalizeTouchSource
} from "@/lib/lead-pipeline";

const ALLOWED_STATUS = new Set<string>(STATUSES);
const ALLOWED_TOUCH = new Set<string>(TOUCH_OPTIONS);

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await request.json();
    const db = supabaseAdmin();

    const { data: existing, error: existingError } = await db
      .from("leads")
      .select("*")
      .eq("id", id)
      .single();

    if (existingError) throw existingError;

    const patch: Record<string, any> = {};

    if (body.status !== undefined) {
      const requestedStatus = normalizeLeadStatus(String(body.status));

      if (!ALLOWED_STATUS.has(requestedStatus)) {
        return NextResponse.json(
          { ok: false, error: `Invalid status: ${body.status}` },
          { status: 400 }
        );
      }

      patch.status = requestedStatus;

      if (requestedStatus === "Closing" && existing.status !== "Closing") {
        patch.closed_at = new Date().toISOString();
      } else if (
        requestedStatus !== "Closing" &&
        existing.status === "Closing"
      ) {
        patch.closed_at = null;
      }
    }

    if (body.last_touch_source !== undefined) {
      const requestedTouch = normalizeTouchSource(
        String(body.last_touch_source || "")
      );

      if (!ALLOWED_TOUCH.has(requestedTouch)) {
        return NextResponse.json(
          { ok: false, error: `Invalid touch/trigger: ${requestedTouch}` },
          { status: 400 }
        );
      }

      patch.last_touch_source = requestedTouch;

      if (requestedTouch !== String(existing.last_touch_source || "")) {
        patch.last_touch_at = new Date().toISOString();
      }
    }

    if (body.revenue !== undefined) {
      const revenue = Number(body.revenue);

      if (!Number.isFinite(revenue) || revenue < 0) {
        return NextResponse.json(
          { ok: false, error: "Invalid revenue" },
          { status: 400 }
        );
      }

      patch.revenue = revenue;
    }

    if (body.notes !== undefined) {
      patch.notes = String(body.notes ?? "").slice(0, 5000);
    }

    // Keep `source` as first-touch acquisition. Touch/trigger is stored
    // separately in `last_touch_source`, so changing Broadcast/Follow-up
    // never steals first-touch credit from Meta Ads or Organic.

    const nextStatus = patch.status ?? normalizeLeadStatus(existing.status);
    const nextTouch =
      patch.last_touch_source ??
      existing.last_touch_source ??
      existing.source ??
      null;

    if (
      nextStatus === "Closing" &&
      existing.status !== "Closing" &&
      nextTouch
    ) {
      patch.closing_trigger = nextTouch;
    }

    if (Object.keys(patch).length === 0) {
      return NextResponse.json(
        { ok: false, error: "Tidak ada perubahan untuk disimpan." },
        { status: 400 }
      );
    }

    const { data: updated, error: updateError } = await db
      .from("leads")
      .update(patch)
      .eq("id", id)
      .select("*")
      .single();

    if (updateError) throw updateError;

    // Verify what Supabase actually persisted before telling the UI success.
    if (patch.status !== undefined && updated.status !== patch.status) {
      throw new Error(
        `Status tidak tersimpan. Requested=${patch.status}, DB=${updated.status}`
      );
    }

    if (
      patch.last_touch_source !== undefined &&
      updated.last_touch_source !== patch.last_touch_source
    ) {
      throw new Error(
        `Touch/Trigger tidak tersimpan. Requested=${patch.last_touch_source}, DB=${updated.last_touch_source}`
      );
    }

    if (
      patch.revenue !== undefined &&
      Number(updated.revenue || 0) !== Number(patch.revenue)
    ) {
      throw new Error(
        `Revenue tidak tersimpan. Requested=${patch.revenue}, DB=${updated.revenue}`
      );
    }

    if (patch.status !== undefined && patch.status !== existing.status) {
      const { error: eventError } = await db
        .from("lead_status_events")
        .insert({
          lead_id: id,
          old_status: existing.status,
          new_status: patch.status,
          revenue: updated.revenue ?? 0
        });

      // The CRM update has already succeeded; audit logging must not make
      // the user think the lead itself failed to save.
      if (eventError) {
        console.error("lead_status_events insert failed:", eventError);
      }
    }

    const capi: Record<string, any> = {};
    const capiAllowed = !updated.suppress_capi && Boolean(updated.ctwa_clid);

    // Preserve the previous behavior: a lead may be reported once it reaches
    // Estimasi or any later funnel stage. ESTIMATE_STATUSES is shared with the
    // dashboard so API and UI cannot drift apart again.
    if (
      ESTIMATE_STATUSES.has(normalizeLeadStatus(updated.status)) &&
      !updated.capi_lead_sent_at &&
      capiAllowed
    ) {
      try {
        const leadResult = await sendMessagingConversion(
          updated,
          "LeadSubmitted"
        );

        capi.lead = leadResult;

        if (leadResult.ok && !leadResult.skipped) {
          const sentAt = new Date().toISOString();

          await db
            .from("leads")
            .update({
              capi_lead_sent_at: sentAt,
              capi_last_error: null
            })
            .eq("id", id);

          updated.capi_lead_sent_at = sentAt;
          updated.capi_last_error = null;
        } else if (!leadResult.ok && !leadResult.skipped) {
          await db
            .from("leads")
            .update({
              capi_last_error:
                leadResult.reason ?? "LeadSubmitted failed"
            })
            .eq("id", id);

          updated.capi_last_error =
            leadResult.reason ?? "LeadSubmitted failed";
        }
      } catch (capiError: any) {
        capi.lead = {
          ok: false,
          reason:
            capiError?.message ||
            "Lead tersimpan, tetapi Meta CAPI error."
        };
      }
    }

    if (
      normalizeLeadStatus(updated.status) === "Closing" &&
      Number(updated.revenue || 0) > 0 &&
      !updated.capi_purchase_sent_at &&
      capiAllowed
    ) {
      try {
        const purchaseResult = await sendMessagingConversion(
          updated,
          "Purchase"
        );

        capi.purchase = purchaseResult;

        if (purchaseResult.ok && !purchaseResult.skipped) {
          const sentAt = new Date().toISOString();

          await db
            .from("leads")
            .update({
              capi_purchase_sent_at: sentAt,
              capi_last_error: null
            })
            .eq("id", id);

          updated.capi_purchase_sent_at = sentAt;
          updated.capi_last_error = null;
        } else if (!purchaseResult.ok && !purchaseResult.skipped) {
          await db
            .from("leads")
            .update({
              capi_last_error:
                purchaseResult.reason ?? "Purchase failed"
            })
            .eq("id", id);

          updated.capi_last_error =
            purchaseResult.reason ?? "Purchase failed";
        }
      } catch (capiError: any) {
        capi.purchase = {
          ok: false,
          reason:
            capiError?.message ||
            "Closing tersimpan, tetapi Meta CAPI error."
        };
      }
    }

    return NextResponse.json({
      ok: true,
      lead: updated,
      capi,
      saved: {
        source: updated.source,
        last_touch_source: updated.last_touch_source,
        status: updated.status,
        revenue: Number(updated.revenue || 0)
      }
    });
  } catch (error: any) {
    console.error("PATCH /api/leads/[id] failed:", error);

    return NextResponse.json(
      {
        ok: false,
        error: error?.message || "Failed to update lead"
      },
      { status: 500 }
    );
  }
}
